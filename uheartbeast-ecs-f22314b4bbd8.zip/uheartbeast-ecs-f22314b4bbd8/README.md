# README #

### What is this repository for? ###

This is my very first entity component system and the first game I've ever made using love2D. It has flaws but I think it might be useful for some people wanting to learn more about entity component systems.