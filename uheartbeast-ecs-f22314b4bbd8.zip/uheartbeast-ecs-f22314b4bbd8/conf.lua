function love.conf(table)
    table.window.width = 360
    table.window.height = 640
end